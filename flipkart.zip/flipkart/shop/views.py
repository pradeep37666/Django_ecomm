from django.shortcuts import render, redirect,HttpResponseRedirect
from django.views.generic import View
from .models.product import Product, Category
from .models.customer import Customer
from .models.orders import Order
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from .middlewares.auth import auth_middleware

# Create your views here.


def first(request):
    if request.method == 'GET':
     #    request.session.get('cart').clear()
        products = None
        categories = Category.objects.all()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.objects.filter(category=categoryID)
        else:
            products = Product.objects.all()
        data = {}
        data['products'] = products
        data['categories'] = categories
        if  not request.session.get('cart'):
            request.session['cart']={}
        
       

        return render(request, "index.html", data)

    elif request.method == "POST":
        if request.POST.get('cart'):
            productid = request.POST.get("cart")
            # making cart object in session dictonarty
            cart = request.session.get('cart')
            print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",cart)
            if cart:
                quantity = cart.get(productid)
                # print("**************************************************",quantity)
                if quantity:
                    cart[productid] = quantity+1
                else:
                    cart[productid] = 1

            else:
                cart = {}
                cart[productid] = 1

            request.session['cart'] = cart
            print(request.session.get("customer_name"))
            # # print("********!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",
            #       request.session["cart"])

            # print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", productid)
            return redirect("index")
        elif request.POST.get("logout"):
            del request.session['customer_id']
            del request.session['customer_email']
            del request.session['customer_name']
            empty={}
            request.session['cart']=empty
            # print(
            #     "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ cart delete")

            return redirect("index")


# -----------------------------------------------------------------------------------------------------------

def SignUpValidation(customer_obj, confirmPassword):

    error_message = None
    if not customer_obj.first_name:
        error_message = "first name required"
        first_name = ""
    elif not customer_obj.last_name:
        error_message = "last name required"
        last_name = ""
    elif not customer_obj.email:
        error_message = "email required"
        email = ""
    elif not customer_obj.password:
        error_message = "password required"
    elif not confirmPassword:
        error_message = "confirm password required"
    elif customer_obj.password != confirmPassword:
        error_message = "password not matching"

    return error_message


def login(request):
    return_Url  =None
    login.return_Url =request.GET.get('return_Url')


    if request.method == 'GET':

        return render(request, "login.html")
    else:
        if request.POST.get('signup'):
            signup_error = ""
            first_name = request.POST.get('firstname')
            last_name = request.POST.get('lastname')
            email = request.POST.get('email')
            password = request.POST.get('password')
            confirmPassword = request.POST.get('confPassword')
            print("signnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn")

            customer_obj = Customer(
                first_name=first_name, last_name=last_name, email=email, password=password)

            error_message = SignUpValidation(
                customer_obj, confirmPassword)  # function calling
            # form validation
            print("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",error_message)
            if Customer.objects.filter(email=email):
                error_message = "This email is alredy registered"

            if error_message:
                signup_error = " error! please signup again"

            userdata = {"fs_name": first_name,
                        "ls_name": last_name, "e_mail": email}

            if not error_message:
                customer_obj.password = make_password(
                    customer_obj.password)  # hasing of password
                customer_obj.save()
                print("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS")
                return render(request,"login.html",{'error':'suscessfully Register! Please login','bgcol':'#00C853'})

                
            else:
                data = {'error': error_message, 'values': userdata,
                        'signerror': signup_error,'bgcol':'#D50000' }
                return render(request, "login.html", data)

        # user sign in work
        elif request.POST.get("signin"):
            error_message = ""
            email = request.POST.get("email")
            password = request.POST.get("password")
            customer_email = Customer.objects.get(email=email)

            if customer_email:
                if check_password(password, customer_email.password):
                    request.session['customer_id'] = customer_email.id
                    request.session['customer_email'] = customer_email.email
                    request.session['customer_name'] = customer_email.first_name

                    if login.return_Url:
                        return HttpResponseRedirect(login.return_Url)
                        
                    else:
                        login.return_Url=None
                        return redirect("index")


                    return redirect("index")
                else:
                    error_message = "email or password invalid"
            else:
                error_message = "email or password invalid"

            return render(request, "login.html", {'error': error_message,'bgcol':'#D50000'})


def CartsItems(request):
    if request.method == "GET":
        items = {}
        Plist = []
        Qlist = []
        total =0
        totalitems =0
        if  not request.session.get('cart'):
                request.session['cart']={}

        carts = request.session["cart"]
        for key, value in carts.items():
            product = Product.objects.filter(id=key)
            # print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@", request.session["cart"])
            # print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",product.price)
            # Plist.append(product)
            totalitems = totalitems + int(value)
            Plist.append(product)
            Qlist.append(value)
            for p in product:
               total = total+ p.price*int(value)



           
            
        # print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",total,totalitems)
        items["prod"] = Plist
        items["quantity"] = Qlist

        # print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,", Plist, Qlist)

        items["totalitems"] = totalitems
        items['totalamount'] = total
        # items["totalamount"] = total
        # print("*****************************************", items)

        return render(request, "carts.html", items)

    elif request.method == "POST":
                       

        if request.POST.get("plus"):
            productid = request.POST.get("plus")
            # making cart object in session dictonarty
            cart = request.session.get('cart')
            # print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",cart)
            if cart:
                quantity = cart.get(productid)
                # print("**************************************************",quantity)
                if quantity:
                    cart[productid] = quantity+1
                else:
                    cart[productid] = 1

            else:
                cart = {}
                cart[productid] = 1

            request.session['cart'] = cart
            # print(request.session.get("customer_name"))
            # print("********!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",request.session["cart"])

            return redirect("cartsItems")


        elif request.POST.get("minus"):
            productid = request.POST.get("minus")
            # making cart object in session dictonarty
            cart = request.session.get('cart')
            # print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk",cart)
            if cart:
                quantity = cart.get(productid)
                # print("**************************************************",quantity)
                if quantity!=1:
                    cart[productid] = quantity-1
                else:
                    del cart[productid] 

            request.session['cart'] = cart
            # print(request.session.get("customer_name"))
            # print("********!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",request.session["cart"])

            return redirect("cartsItems")

       



def order(request):

    if request.method == "GET":
        customer =request.session.get('customer_id')
        order =Order.objects.filter(customer=customer)
        sum=0
        for i in order:
            sum=sum+i.price
        sum="₹"+str(sum)    


       

        return render(request,"order.html",{"order":order,"TotalAmount":sum})    
       

           
            
       

def search(request):
    query=request.GET["query"]
    products = {}
    if len(query)>66:
        product = {}
    else:    
        products = Product.objects.filter(name__icontains=query)
        products_desc = Product.objects.filter(desc__icontains=query)
       

        products  =  (products  | products_desc).distinct()
        
        # products = products.union(products_cate)

    return render(request,"search.html",{"products":products,"query":query})
                

def checkout(request):
    if request.method == "POST":
        add = request.POST.get("add")
        phone = request.POST.get("phone")
        city = request.POST.get("city")
        district = request.POST.get("district")
        if  not request.session.get("customer_id"):
            return redirect("login")
        customer  = request.session.get("customer_id")
        customer =Customer.objects.get(id=customer)
        cart= request.session.get('cart')
        # print("hhgggggggggggggggggggggggggggggggggggggggggggggggggggg",customer)
        products=[]
        for id ,quantity in cart.items():
            
            product = Product.objects.filter(id=int(id))
            # print("jdffffkbffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",product)
            for prod in product:
                # print("j????????????????????????????????????????????????????????????????",prod.name)
                order =     Order(product=prod,customer=customer,quantity=int(quantity),price=(prod.price*quantity),
                address=add,phoneNo=phone,city=city,district=district )
                order.save()


        request.session['cart'] ={}

        # print("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::;;;;;;;;",products,cart.keys(),type(cart.keys()))


        # print("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh",request.POST.get("checkoutbtn"))    
        return redirect("order")

def logout(request):
            request.session.clear()
            request.session["cart"] ={}
            # print(
            #     "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ cart delete")

            return redirect("index")


def contact(request):
    return render(request,"contact.html")