from django.db import models
from .prod_category import Category


class Product(models.Model):
    name = models.CharField(max_length=30)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    desc = models.CharField(max_length=300,default='')
    photo = models.ImageField(upload_to="gallary")

    def __str__(self):
        return self.name

    class Meta:
        ordering =['category']