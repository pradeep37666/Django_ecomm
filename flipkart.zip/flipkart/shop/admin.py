from django.contrib import admin
from  .models.prod_category import Category
from .models.product import Product
from .models.customer import Customer
from .models.orders import Order

class AdminProduct(admin.ModelAdmin):
    list_display=['name','price','category']
    list_filter=['category']

class AdminOrder(admin.ModelAdmin):
    list_display=['updated_at','created_at','customer','product']    
    

# Register your models here.
# admin.site.register(Product)
admin.site.register(Category)
admin.site.register(Product,AdminProduct)
admin.site.register(Customer)
admin.site.register(Order,AdminOrder)

