from django import template

register = template.Library()


@register.filter(name="quantity")
def quantity( key , cart):
    temp=0
    print("111111111111111111111111111111111111111111111111111111111111",key)
    print( type(key))
    for k, v in cart.items():
        print("************************************************",k)
        print( type(k))
        if key == int(k):
            temp=int(v)
          
    return temp

@register.filter(name="totalitemsPrice")
def totalitemsPrice(j ,cart) :
        itemtotal =0
        price =j.price
        id = int(j.id)

       
        for k, v in cart.items():
            if itemtotal ==0 and id==int(k):
               itemtotal =  price*int(v)
        print("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz",itemtotal)

        return itemtotal 
@register.filter(name="currency")
def currency(price):
    return "₹" +" "    


@register.filter(name="counter")
def counter(id ,cart):
    keylist= cart.keys()
    keylist = list(keylist)
    count =0
    for i in keylist:
        count+=1
        if  int(i)== int(id):
            return count

      


        