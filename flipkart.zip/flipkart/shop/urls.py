
from .middlewares.auth import auth_middleware
from .import views
from django.urls import path

urlpatterns = [
    path('',views.first,name="index"),
     path('index',views.first,name="index"),
    path('login',views.login, name="login"),
    path('cartsItems',views.CartsItems,name="cartsItems"),
    path("checkout",views.checkout,name="checkout"),
    path("order",auth_middleware(views.order),name="order"),
    path("search",views.search,name="search"),
    path("logout",views.logout,name="logout"),
    path("contact",views.contact,name="logout")
   
]
